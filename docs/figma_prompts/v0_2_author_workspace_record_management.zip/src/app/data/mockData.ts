import { Record, Comment, User } from '../types';

export const mockRecords: Record[] = [
  {
    id: '1',
    title: 'On the Nature of Time in Literature',
    contents: `# On the Nature of Time in Literature

Time in literature is not merely a backdrop against which events unfold, but rather a malleable substance that writers shape and reshape to serve their narrative purposes. Unlike the inexorable march of chronological time we experience in daily life, literary time can expand, contract, loop back upon itself, or fragment into shimmering pieces.

## The Elastic Quality of Narrative Time

Consider how Proust stretches a single moment—the taste of a madeleine—into hundreds of pages of memory and reflection. Or how García Márquez compresses a century of family history into a narrative that feels both epic and intimate. These manipulations of temporal flow are not mere tricks but fundamental to how stories create meaning.

> "Time is a river which sweeps me along, but I am the river; it is a tiger which destroys me, but I am the tiger; it is a fire which consumes me, but I am the fire." — Jorge Luis Borges

## Multiple Temporalities

Modern narratives often operate on multiple temporal planes simultaneously. The reader experiences:

1. **Story time** - the chronological sequence of events
2. **Discourse time** - the order in which events are presented
3. **Reading time** - the actual duration of reading experience

These layers create a rich temporal texture that allows literature to explore consciousness in ways other media cannot quite replicate.

The relationship between memory and narrative time remains one of the most fertile grounds for literary exploration, as our memories themselves operate more like literature than like documentary film—selective, reconstructed, shaped by emotion and significance rather than mere chronology.`,
    sourceType: 'article',
    visibility: 'public',
    publishedDate: '2026-03-10T14:30:00Z',
    writer: 'Elena Vasquez',
    tags: ['literature', 'time', 'narrative theory', 'modernism']
  },
  {
    id: '2',
    title: 'The Architecture of Silence',
    contents: `# The Architecture of Silence

In Japanese aesthetics, *ma* (間) refers to the space between things—the pause, the interval, the emptiness that gives shape to form. This concept finds its architectural expression in the traditional tea house, where simplicity creates a vessel for contemplation.

## Emptiness as Presence

The power of *ma* lies in its recognition that what is absent can be as important as what is present. In a well-designed space, silence is not merely the absence of sound, but an active participant in the experience.

Modern architecture often fills every corner, eliminates every pause. But the most profound spaces breathe. They allow for:

- Moments of transition
- Periods of rest
- Intervals of reflection

## Learning from Traditional Forms

The engawa (縁側), the transitional space between interior and exterior in Japanese homes, embodies this principle perfectly. Neither fully inside nor outside, it creates a threshold experience—a breathing space between realms.

Contemporary designers who understand this principle create buildings that don't merely occupy space but articulate it, giving rhythm and breath to our daily movements through the built environment.`,
    sourceType: 'article',
    visibility: 'public',
    publishedDate: '2026-03-08T09:15:00Z',
    writer: 'James Morrison',
    tags: ['architecture', 'Japanese aesthetics', 'design', 'minimalism']
  },
  {
    id: '3',
    title: 'Notes on Craftsmanship in the Digital Age',
    contents: `# Notes on Craftsmanship in the Digital Age

The word "craft" carries within it centuries of accumulated meaning—the patient development of skill, the intimate knowledge of materials, the satisfaction of work well done. What happens to these values when our primary material becomes immaterial?

## The Paradox of Digital Making

Software development, at its best, exhibits all the hallmarks of traditional craft:

- Deep understanding of the medium
- Attention to detail and finish
- Care for the end user's experience
- Pride in workmanship

Yet the digital realm presents unique challenges. The "material" is infinitely malleable, changes can be undone instantly, and the craftsperson's hand is invisible in the final product.

## Slowing Down to Speed Up

Paradoxically, the fastest way to build good software is often to slow down—to think deeply about structure, to refactor patiently, to test thoroughly. This mirrors the craftsperson's understanding that preparation and proper technique ultimately save time and produce superior results.

> "The craftsman must have a way of life that is itself beautiful and harmonious." — Soetsu Yanagi

The challenge is maintaining craft values in an environment that constantly pressures us toward speed, scale, and novelty. Yet those who do manage this balance create digital experiences that feel solid, considered, and humane—artifacts that honor both maker and user.`,
    sourceType: 'article',
    visibility: 'public',
    publishedDate: '2026-03-05T16:45:00Z',
    writer: 'Sarah Chen',
    tags: ['craftsmanship', 'software', 'philosophy', 'design']
  },
  {
    id: '4',
    title: 'Walking as Meditation',
    contents: `# Walking as Meditation

There is something fundamentally human about walking. Our bodies evolved for it, our minds settle into its rhythm. In an age of constant acceleration, the simple act of walking becomes a form of resistance.

## The Rhythm of Thought

Many great thinkers were walkers. Rousseau, Kant, Nietzsche—all found that walking unlocked something in their thinking. The steady rhythm of footsteps seems to provide a metronome for thought, neither so fast as to scatter concentration nor so slow as to allow stagnation.

Walking meditation, as practiced in many Buddhist traditions, makes this connection explicit. Each step becomes an anchor for awareness, a return to the present moment.

## Urban Walking and Attention

The city walker—the flâneur—practices a different kind of meditation. Here, the practice involves opening attention rather than narrowing it, allowing the urban environment to present itself without agenda or destination.

Walter Benjamin wrote beautifully about this mode of attention:

> "The street conducts the flâneur into a vanished time."

To walk in a city is to read it, to allow its layers of history, culture, and life to reveal themselves at walking pace. This cannot be done from a car, barely even from a bicycle. Walking gives the city time to speak.

In our accelerated world, perhaps the most radical act is simply to walk—to move through space at human speed, attending to what is actually present rather than what might be next.`,
    sourceType: 'book',
    bookTitle: 'The Practice of Attention: Essays on Slowness',
    visibility: 'public',
    publishedDate: '2026-02-28T11:20:00Z',
    writer: 'Michael Torres',
    tags: ['walking', 'meditation', 'urban studies', 'philosophy', 'mindfulness']
  },
  {
    id: '5',
    title: 'Draft: The Problem of Authenticity',
    contents: `# The Problem of Authenticity

This is a work in progress exploring the concept of authenticity in contemporary culture.

## Questions to explore:
- What does it mean to be authentic?
- How does social media affect our sense of authenticity?
- Is there value in performativity?

More to come...`,
    sourceType: 'article',
    visibility: 'private',
    publishedDate: '2026-03-12T08:00:00Z',
    writer: 'Elena Vasquez',
    tags: ['authenticity', 'draft', 'culture']
  },
  {
    id: '6',
    title: 'Personal Notes on Gardening',
    contents: `# Personal Notes on Gardening

Some thoughts about my garden this spring.

The tomatoes are doing well, but the lettuce bolted too early. Need to plant in shadier spot next year.`,
    sourceType: 'article',
    visibility: 'private',
    publishedDate: '2026-03-13T10:30:00Z',
    writer: 'Elena Vasquez',
    tags: ['personal', 'gardening']
  }
];

export const mockComments: Comment[] = [
  {
    id: 'c1',
    recordId: '1',
    author: 'David Kim',
    content: 'This beautifully articulates something I\'ve felt but never quite put into words. The Proust example is perfect—those madeleine passages really do stretch time in an almost physical way.',
    createdAt: '2026-03-11T10:30:00Z'
  },
  {
    id: 'c2',
    recordId: '1',
    author: 'Rachel Goldman',
    content: 'Have you read Paul Ricoeur\'s "Time and Narrative"? He explores these ideas in fascinating depth, particularly the relationship between lived time and narrative time.',
    createdAt: '2026-03-11T14:15:00Z'
  },
  {
    id: 'c3',
    recordId: '1',
    author: 'Elena Vasquez',
    content: 'I haven\'t read that specific work, but I\'m familiar with Ricoeur. Will definitely add it to my reading list—thank you for the recommendation!',
    createdAt: '2026-03-11T15:45:00Z',
    parentId: 'c2'
  },
  {
    id: 'c4',
    recordId: '2',
    author: 'Lisa Anderson',
    content: 'The concept of ma has completely changed how I think about design. Sometimes the most important design decision is what to leave out.',
    createdAt: '2026-03-09T08:20:00Z'
  },
  {
    id: 'c5',
    recordId: '4',
    author: 'Thomas Wright',
    content: 'As someone who walks to work every day, this resonates deeply. Those 25 minutes are often when I do my best thinking.',
    createdAt: '2026-03-01T09:30:00Z'
  }
];

export const currentUser: User | null = null; // Not logged in by default

// Helper to get/set current user from localStorage
export function getCurrentUser(): User | null {
  const stored = localStorage.getItem('currentUser');
  return stored ? JSON.parse(stored) : null;
}

export function setCurrentUser(user: User | null): void {
  if (user) {
    localStorage.setItem('currentUser', JSON.stringify(user));
  } else {
    localStorage.removeItem('currentUser');
  }
  // Dispatch custom event for same-tab auth changes
  window.dispatchEvent(new Event('authChange'));
}

export function getUserRecords(userName: string): Record[] {
  return mockRecords.filter(r => r.writer === userName);
}

export function getRecordById(id: string): Record | undefined {
  return mockRecords.find(r => r.id === id);
}

export function getCommentsByRecordId(recordId: string): Comment[] {
  const comments = mockComments.filter(c => c.recordId === recordId && !c.parentId);
  return comments.map(comment => ({
    ...comment,
    replies: mockComments.filter(c => c.parentId === comment.id)
  }));
}

export function getRelatedRecords(recordId: string, limit: number = 3): Record[] {
  const record = getRecordById(recordId);
  if (!record) return [];
  
  // Find records with overlapping tags
  const relatedRecords = mockRecords
    .filter(r => r.id !== recordId && r.visibility === 'public')
    .map(r => ({
      record: r,
      score: r.tags.filter(tag => record.tags.includes(tag)).length
    }))
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(item => item.record);
  
  return relatedRecords;
}