import { Outlet } from 'react-router';
import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { getCurrentUser } from './data/mockData';

export function Root() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    // Check auth state on mount and when returning to page
    const checkAuth = () => {
      const user = getCurrentUser();
      setIsAuthenticated(!!user);
    };
    
    checkAuth();
    
    // Listen for storage changes (for multi-tab support)
    window.addEventListener('storage', checkAuth);
    
    // Custom event for same-tab auth changes
    window.addEventListener('authChange', checkAuth);
    
    return () => {
      window.removeEventListener('storage', checkAuth);
      window.removeEventListener('authChange', checkAuth);
    };
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Header isAuthenticated={isAuthenticated} />
      <main className="flex-1">
        <Outlet />
      </main>
      <footer className="border-t border-border bg-card/30 mt-auto">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-sm text-muted-foreground">
            <p>Personal Wiki · A space for thoughtful writing and reading</p>
            <p className="mt-2">© 2026 All rights reserved</p>
          </div>
        </div>
      </footer>
    </div>
  );
}