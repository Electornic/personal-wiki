export interface Record {
  id: string;
  title: string;
  contents: string;
  sourceType: 'article' | 'book';
  bookTitle?: string;
  visibility: 'public' | 'private';
  publishedDate: string;
  writer: string;
  tags: string[];
}

export interface Comment {
  id: string;
  recordId: string;
  author: string;
  content: string;
  createdAt: string;
  parentId?: string;
  replies?: Comment[];
}

export interface User {
  id: string;
  name: string;
  email: string;
}
