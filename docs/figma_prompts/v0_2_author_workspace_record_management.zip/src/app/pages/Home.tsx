import { mockRecords } from '../data/mockData';
import { RecordCard } from '../components/RecordCard';

export function Home() {
  const publicRecords = mockRecords.filter(r => r.visibility === 'public');

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Hero Section */}
      <div className="mb-16 text-center max-w-3xl mx-auto">
        <h1 className="text-5xl sm:text-6xl mb-6">
          A Space for Reading & Reflection
        </h1>
        <p className="text-xl text-foreground/70 leading-relaxed">
          Thoughtful essays, book notes, and explorations on literature, design, philosophy, and the art of attention.
        </p>
      </div>

      {/* Records Grid */}
      <div className="space-y-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-3xl">Recent Entries</h2>
          <span className="text-sm text-muted-foreground">
            {publicRecords.length} {publicRecords.length === 1 ? 'entry' : 'entries'}
          </span>
        </div>
        
        <div className="grid gap-6">
          {publicRecords.map(record => (
            <RecordCard key={record.id} record={record} />
          ))}
        </div>
      </div>

      {publicRecords.length === 0 && (
        <div className="text-center py-20">
          <p className="text-xl text-muted-foreground">No public entries yet.</p>
        </div>
      )}
    </div>
  );
}
