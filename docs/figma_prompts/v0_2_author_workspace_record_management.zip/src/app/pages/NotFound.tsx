import { Link } from 'react-router';
import { Button } from '../components/ui/button';
import { ArrowLeft } from 'lucide-react';

export function NotFound() {
  return (
    <div className="min-h-[calc(100vh-16rem)] flex items-center justify-center px-4">
      <div className="text-center max-w-md">
        <h1 className="text-6xl mb-4">404</h1>
        <h2 className="text-2xl mb-4">Page Not Found</h2>
        <p className="text-lg text-muted-foreground mb-8">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <Button asChild>
          <Link to="/" className="gap-2">
            <ArrowLeft className="w-4 h-4" />
            Return to Library
          </Link>
        </Button>
      </div>
    </div>
  );
}
