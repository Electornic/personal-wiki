import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Eye, Edit, Trash2, Plus, LogOut, BookOpen, FileText, Lock, Globe } from 'lucide-react';
import { getCurrentUser, setCurrentUser, getUserRecords } from '../data/mockData';
import type { Record, User } from '../types';

export function Workspace() {
  const navigate = useNavigate();
  const [user, setUser] = useState<User | null>(null);
  const [records, setRecords] = useState<Record[]>([]);

  useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      navigate('/auth');
      return;
    }
    setUser(currentUser);
    const userRecords = getUserRecords(currentUser.name);
    // Sort by published date, newest first
    const sortedRecords = [...userRecords].sort((a, b) => 
      new Date(b.publishedDate).getTime() - new Date(a.publishedDate).getTime()
    );
    setRecords(sortedRecords);
  }, [navigate]);

  const handleSignOut = () => {
    setCurrentUser(null);
    navigate('/');
  };

  const handleNewRecord = () => {
    navigate('/editor');
  };

  const handleEdit = (id: string) => {
    navigate(`/editor/${id}`);
  };

  const handlePreview = (id: string) => {
    navigate(`/record/${id}`);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this record?')) {
      setRecords(records.filter(r => r.id !== id));
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-5xl mx-auto px-6 py-12 md:py-20">
        {/* Header */}
        <header className="mb-16">
          <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-6 mb-8">
            <div>
              <h1 className="mb-2">Workspace</h1>
              <p className="text-muted-foreground font-['Inter'] text-sm">
                Signed in as <span className="text-foreground">{user.name}</span>
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={handleNewRecord}
                className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors"
              >
                <Plus className="w-4 h-4" />
                New Record
              </button>
              <button
                onClick={handleSignOut}
                className="inline-flex items-center justify-center gap-2 px-6 py-3 border border-border rounded-md hover:bg-muted/50 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </button>
            </div>
          </div>

          <div className="h-px bg-border" />
        </header>

        {/* Records List */}
        {records.length === 0 ? (
          <div className="text-center py-20">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-6">
              <FileText className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="mb-3">No records yet</h3>
            <p className="text-muted-foreground mb-8 max-w-md mx-auto">
              Start building your personal library by creating your first record.
            </p>
            <button
              onClick={handleNewRecord}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors"
            >
              <Plus className="w-4 h-4" />
              Create First Record
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            {records.map((record) => (
              <article
                key={record.id}
                className="bg-card border border-border rounded-lg p-6 hover:shadow-sm transition-shadow"
              >
                <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    {/* Title and Visibility */}
                    <div className="flex items-start gap-3 mb-3">
                      <h3 className="flex-1 min-w-0 break-words">
                        {record.title}
                      </h3>
                      <div className="flex-shrink-0">
                        {record.visibility === 'public' ? (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-secondary text-foreground font-['Inter'] text-xs font-medium">
                            <Globe className="w-3 h-3" />
                            Public
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-muted text-muted-foreground font-['Inter'] text-xs font-medium">
                            <Lock className="w-3 h-3" />
                            Private
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Metadata */}
                    <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground font-['Inter']">
                      <div className="flex items-center gap-1.5">
                        {record.sourceType === 'book' ? (
                          <BookOpen className="w-4 h-4" />
                        ) : (
                          <FileText className="w-4 h-4" />
                        )}
                        <span className="capitalize">{record.sourceType}</span>
                      </div>
                      
                      {record.sourceType === 'book' && record.bookTitle && (
                        <span className="text-foreground">
                          {record.bookTitle}
                        </span>
                      )}
                      
                      <span>{formatDate(record.publishedDate)}</span>
                      
                      {record.tags.length > 0 && (
                        <div className="flex flex-wrap gap-2">
                          {record.tags.slice(0, 3).map((tag) => (
                            <span
                              key={tag}
                              className="px-2 py-0.5 rounded-md bg-muted text-xs"
                            >
                              {tag}
                            </span>
                          ))}
                          {record.tags.length > 3 && (
                            <span className="text-xs">
                              +{record.tags.length - 3} more
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button
                      onClick={() => handlePreview(record.id)}
                      className="inline-flex items-center justify-center gap-2 px-4 py-2 border border-border rounded-md hover:bg-muted/50 transition-colors font-['Inter'] text-sm"
                      title="Preview"
                    >
                      <Eye className="w-4 h-4" />
                      <span className="hidden sm:inline">Preview</span>
                    </button>
                    <button
                      onClick={() => handleEdit(record.id)}
                      className="inline-flex items-center justify-center gap-2 px-4 py-2 border border-border rounded-md hover:bg-muted/50 transition-colors font-['Inter'] text-sm"
                      title="Edit"
                    >
                      <Edit className="w-4 h-4" />
                      <span className="hidden sm:inline">Edit</span>
                    </button>
                    <button
                      onClick={() => handleDelete(record.id)}
                      className="inline-flex items-center justify-center p-2 border border-border rounded-md hover:bg-destructive/10 hover:border-destructive/30 transition-colors text-destructive"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}