import { Link } from 'react-router';
import { Record } from '../types';
import { TagBadge } from './TagBadge';
import { BookOpen, FileText } from 'lucide-react';
import { format } from 'date-fns';

interface RecordCardProps {
  record: Record;
}

export function RecordCard({ record }: RecordCardProps) {
  const excerpt = record.contents
    .replace(/^#.*$/gm, '') // Remove markdown headers
    .replace(/[*_~`]/g, '') // Remove markdown formatting
    .trim()
    .split('\n')
    .filter(line => line.trim().length > 0)[0] || '';

  return (
    <Link to={`/record/${record.id}`} className="block group">
      <article className="bg-card border border-border rounded-lg p-6 hover:shadow-md transition-shadow">
        <div className="flex items-start gap-3 mb-3">
          <div className="mt-1 text-muted-foreground">
            {record.sourceType === 'book' ? (
              <BookOpen className="w-5 h-5" />
            ) : (
              <FileText className="w-5 h-5" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-2xl mb-1 group-hover:text-primary/80 transition-colors line-clamp-2">
              {record.title}
            </h3>
            {record.sourceType === 'book' && record.bookTitle && (
              <p className="text-sm text-muted-foreground mb-2 italic">
                from {record.bookTitle}
              </p>
            )}
          </div>
        </div>
        
        <p className="text-base text-foreground/80 mb-4 line-clamp-2 leading-relaxed">
          {excerpt}
        </p>
        
        <div className="flex flex-wrap items-center gap-2 mb-3">
          {record.tags.slice(0, 4).map(tag => (
            <TagBadge key={tag} tag={tag} />
          ))}
        </div>
        
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <span className="font-medium">{record.writer}</span>
          <time dateTime={record.publishedDate}>
            {format(new Date(record.publishedDate), 'MMM d, yyyy')}
          </time>
        </div>
      </article>
    </Link>
  );
}
