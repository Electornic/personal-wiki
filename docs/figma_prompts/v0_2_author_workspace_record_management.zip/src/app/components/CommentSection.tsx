import { useState } from 'react';
import { Comment } from '../types';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { format } from 'date-fns';
import { MessageCircle, Reply } from 'lucide-react';

interface CommentSectionProps {
  comments: Comment[];
  isAuthenticated?: boolean;
}

function CommentItem({ comment, isAuthenticated, onReply }: { 
  comment: Comment; 
  isAuthenticated: boolean;
  onReply: (commentId: string) => void;
}) {
  return (
    <div className="space-y-3">
      <div className="flex items-start gap-3">
        <div className="w-9 h-9 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
          <span className="text-sm font-medium">
            {comment.author.charAt(0).toUpperCase()}
          </span>
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-baseline gap-2 mb-1">
            <span className="font-medium text-sm">{comment.author}</span>
            <time className="text-xs text-muted-foreground" dateTime={comment.createdAt}>
              {format(new Date(comment.createdAt), 'MMM d, yyyy')}
            </time>
          </div>
          <p className="text-base leading-relaxed mb-2">{comment.content}</p>
          {isAuthenticated && (
            <Button 
              variant="ghost" 
              size="sm" 
              className="gap-1.5 h-8 px-2 text-xs -ml-2"
              onClick={() => onReply(comment.id)}
            >
              <Reply className="w-3 h-3" />
              Reply
            </Button>
          )}
        </div>
      </div>

      {comment.replies && comment.replies.length > 0 && (
        <div className="ml-12 space-y-3 pt-3 border-l-2 border-border pl-6">
          {comment.replies.map(reply => (
            <CommentItem 
              key={reply.id} 
              comment={reply} 
              isAuthenticated={isAuthenticated}
              onReply={onReply}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function CommentSection({ comments, isAuthenticated = false }: CommentSectionProps) {
  const [newComment, setNewComment] = useState('');
  const [replyingTo, setReplyingTo] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would submit to backend
    console.log('Submitting comment:', newComment);
    setNewComment('');
    setReplyingTo(null);
  };

  return (
    <section className="mt-16 pt-12 border-t border-border">
      <div className="flex items-center gap-2 mb-8">
        <MessageCircle className="w-5 h-5 text-muted-foreground" />
        <h3 className="text-2xl">
          Comments
          {comments.length > 0 && (
            <span className="ml-2 text-lg text-muted-foreground">
              ({comments.length})
            </span>
          )}
        </h3>
      </div>

      {/* Comment Form */}
      {isAuthenticated ? (
        <form onSubmit={handleSubmit} className="mb-10">
          <Textarea
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder="Share your thoughts..."
            className="mb-3 min-h-[100px] resize-none"
          />
          <div className="flex justify-end">
            <Button type="submit" disabled={!newComment.trim()}>
              Post Comment
            </Button>
          </div>
        </form>
      ) : (
        <div className="mb-10 p-6 bg-muted/30 border border-border rounded-lg text-center">
          <p className="text-muted-foreground mb-3">
            Sign in to join the conversation
          </p>
          <Button asChild variant="outline" size="sm">
            <a href="/auth">Sign In</a>
          </Button>
        </div>
      )}

      {/* Comments List */}
      {comments.length > 0 ? (
        <div className="space-y-6">
          {comments.map(comment => (
            <CommentItem 
              key={comment.id} 
              comment={comment} 
              isAuthenticated={isAuthenticated}
              onReply={setReplyingTo}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <p className="text-muted-foreground">No comments yet. Be the first to share your thoughts.</p>
        </div>
      )}
    </section>
  );
}
