import { Badge } from './ui/badge';

interface TagBadgeProps {
  tag: string;
}

export function TagBadge({ tag }: TagBadgeProps) {
  return (
    <Badge 
      variant="secondary" 
      className="rounded-full px-3 py-1 text-xs font-normal bg-secondary/60 hover:bg-secondary transition-colors"
    >
      {tag}
    </Badge>
  );
}
