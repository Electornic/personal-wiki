
  # personal-wiki

  This is a code bundle for personal-wiki. The original project is available at https://www.figma.com/design/GPpwlPAIojdKrFl3805VGq/personal-wiki.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  