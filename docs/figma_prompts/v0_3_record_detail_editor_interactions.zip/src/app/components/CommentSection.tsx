import { useState } from 'react';
import { Comment } from '../types';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { format } from 'date-fns';
import { MessageCircle, Reply, X } from 'lucide-react';

interface CommentSectionProps {
  comments: Comment[];
  isAuthenticated?: boolean;
}

function ReplyInput({ 
  onCancel, 
  onSubmit, 
  placeholder = "Write a reply..." 
}: { 
  onCancel: () => void; 
  onSubmit: (content: string) => void;
  placeholder?: string;
}) {
  const [content, setContent] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (content.trim()) {
      onSubmit(content);
      setContent('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="mt-3 animate-in fade-in slide-in-from-top-1 duration-200">
      <Textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder={placeholder}
        className="mb-2 min-h-[80px] resize-none text-sm"
        autoFocus
      />
      <div className="flex justify-end gap-2">
        <Button 
          type="button" 
          variant="ghost" 
          size="sm"
          onClick={onCancel}
        >
          Cancel
        </Button>
        <Button type="submit" size="sm" disabled={!content.trim()}>
          Post Reply
        </Button>
      </div>
    </form>
  );
}

function CommentItem({ comment, isAuthenticated, onReply }: { 
  comment: Comment; 
  isAuthenticated: boolean;
  onReply: (commentId: string) => void;
}) {
  const [showReplyInput, setShowReplyInput] = useState(false);

  const handleReplySubmit = (content: string) => {
    console.log('Submitting reply to', comment.id, ':', content);
    setShowReplyInput(false);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-start gap-3">
        <div className="w-9 h-9 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
          <span className="text-sm font-medium">
            {comment.author.charAt(0).toUpperCase()}
          </span>
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-baseline gap-2 mb-1">
            <span className="font-medium text-sm">{comment.author}</span>
            <time className="text-xs text-muted-foreground" dateTime={comment.createdAt}>
              {format(new Date(comment.createdAt), 'MMM d, yyyy')}
            </time>
          </div>
          <p className="text-base leading-relaxed mb-2">{comment.content}</p>
          {isAuthenticated && (
            <Button 
              variant="ghost" 
              size="sm" 
              className="gap-1.5 h-8 px-2 text-xs -ml-2 hover:bg-muted/50"
              onClick={() => setShowReplyInput(!showReplyInput)}
            >
              <Reply className="w-3 h-3" />
              Reply
            </Button>
          )}
          
          {showReplyInput && (
            <ReplyInput 
              onCancel={() => setShowReplyInput(false)}
              onSubmit={handleReplySubmit}
            />
          )}
        </div>
      </div>

      {comment.replies && comment.replies.length > 0 && (
        <div className="ml-12 space-y-3 pt-3 border-l-2 border-border pl-6">
          {comment.replies.map(reply => (
            <CommentItem 
              key={reply.id} 
              comment={reply} 
              isAuthenticated={isAuthenticated}
              onReply={onReply}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function CommentSection({ comments, isAuthenticated = false }: CommentSectionProps) {
  const [newComment, setNewComment] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would submit to backend
    console.log('Submitting comment:', newComment);
    setNewComment('');
    setIsExpanded(false);
  };

  return (
    <section className="mt-16 pt-12 border-t border-border">
      <div className="flex items-center gap-2 mb-8">
        <MessageCircle className="w-5 h-5 text-muted-foreground" />
        <h3 className="text-2xl">
          Comments
          {comments.length > 0 && (
            <span className="ml-2 text-lg text-muted-foreground">
              ({comments.length})
            </span>
          )}
        </h3>
      </div>

      {/* Comment Form */}
      {isAuthenticated ? (
        <form onSubmit={handleSubmit} className="mb-10">
          {!isExpanded ? (
            <button
              type="button"
              onClick={() => setIsExpanded(true)}
              className="w-full px-4 py-3 bg-muted/20 hover:bg-muted/40 border border-border rounded-lg text-left text-muted-foreground transition-colors"
            >
              Share your thoughts...
            </button>
          ) : (
            <div className="animate-in fade-in slide-in-from-top-2 duration-200">
              <Textarea
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Share your thoughts..."
                className="mb-3 min-h-[120px] resize-none"
                autoFocus
              />
              <div className="flex justify-end gap-2">
                <Button 
                  type="button" 
                  variant="ghost" 
                  onClick={() => {
                    setIsExpanded(false);
                    setNewComment('');
                  }}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={!newComment.trim()}>
                  Post Comment
                </Button>
              </div>
            </div>
          )}
        </form>
      ) : (
        <div className="mb-10 p-6 bg-muted/30 border border-border rounded-lg text-center">
          <p className="text-muted-foreground mb-3">
            Sign in to join the conversation
          </p>
          <Button asChild variant="outline" size="sm">
            <a href="/auth">Sign In</a>
          </Button>
        </div>
      )}

      {/* Comments List */}
      {comments.length > 0 ? (
        <div className="space-y-6">
          {comments.map(comment => (
            <CommentItem 
              key={comment.id} 
              comment={comment} 
              isAuthenticated={isAuthenticated}
              onReply={() => {}}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <p className="text-muted-foreground">No comments yet. Be the first to share your thoughts.</p>
        </div>
      )}
    </section>
  );
}