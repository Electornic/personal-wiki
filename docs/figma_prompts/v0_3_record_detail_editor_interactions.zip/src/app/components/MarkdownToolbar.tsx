import { 
  Bold, 
  Italic, 
  Heading1, 
  Heading2, 
  Heading3, 
  Quote, 
  List, 
  ListOrdered,
  Link as LinkIcon
} from 'lucide-react';
import { Button } from './ui/button';

interface MarkdownToolbarProps {
  onInsert: (before: string, after?: string) => void;
}

export function MarkdownToolbar({ onInsert }: MarkdownToolbarProps) {
  const tools = [
    {
      icon: Heading1,
      label: 'Heading 1',
      action: () => onInsert('# ', ''),
    },
    {
      icon: Heading2,
      label: 'Heading 2',
      action: () => onInsert('## ', ''),
    },
    {
      icon: Heading3,
      label: 'Heading 3',
      action: () => onInsert('### ', ''),
    },
    { divider: true },
    {
      icon: Bold,
      label: 'Bold',
      action: () => onInsert('**', '**'),
    },
    {
      icon: Italic,
      label: 'Italic',
      action: () => onInsert('*', '*'),
    },
    { divider: true },
    {
      icon: Quote,
      label: 'Blockquote',
      action: () => onInsert('> ', ''),
    },
    {
      icon: List,
      label: 'Bullet List',
      action: () => onInsert('- ', ''),
    },
    {
      icon: ListOrdered,
      label: 'Numbered List',
      action: () => onInsert('1. ', ''),
    },
    { divider: true },
    {
      icon: LinkIcon,
      label: 'Link',
      action: () => onInsert('[', '](url)'),
    },
  ];

  return (
    <div className="flex items-center gap-1 p-2 bg-muted/30 border border-border rounded-lg mb-3 overflow-x-auto">
      {tools.map((tool, index) => {
        if ('divider' in tool) {
          return (
            <div
              key={`divider-${index}`}
              className="w-px h-6 bg-border mx-1 flex-shrink-0"
            />
          );
        }

        const Icon = tool.icon;
        return (
          <Button
            key={tool.label}
            type="button"
            variant="ghost"
            size="sm"
            onClick={tool.action}
            className="h-8 w-8 p-0 hover:bg-muted/70 flex-shrink-0"
            title={tool.label}
          >
            <Icon className="w-4 h-4" />
            <span className="sr-only">{tool.label}</span>
          </Button>
        );
      })}
    </div>
  );
}