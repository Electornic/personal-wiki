import { useState, useEffect, useRef } from 'react';
import { useNavigate, Link } from 'react-router';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Switch } from '../components/ui/switch';
import { ArrowLeft, Edit3, Save, Eye } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { getCurrentUser } from '../data/mockData';
import { MarkdownToolbar } from '../components/MarkdownToolbar';

export function Editor() {
  const navigate = useNavigate();
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [title, setTitle] = useState('');
  const [contents, setContents] = useState('');
  const [sourceType, setSourceType] = useState<'article' | 'book'>('article');
  const [bookTitle, setBookTitle] = useState('');
  const [isPublic, setIsPublic] = useState(true);
  const [tags, setTags] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [activeTab, setActiveTab] = useState<'write' | 'preview'>('write');

  useEffect(() => {
    const user = getCurrentUser();
    if (!user) {
      navigate('/auth');
    }
  }, [navigate]);

  const handleSave = async () => {
    setIsSaving(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSaving(false);
      navigate('/workspace');
    }, 1000);
  };

  const handleCancel = () => {
    navigate('/workspace');
  };

  const handleMarkdownInsert = (before: string, after: string = '') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = contents.substring(start, end);
    const beforeText = contents.substring(0, start);
    const afterText = contents.substring(end);

    // Handle line-based formatting (headings, quotes, lists)
    if (before.includes('#') || before.includes('>') || before.includes('-') || before.includes('1.')) {
      if (selectedText) {
        // Format each selected line
        const lines = selectedText.split('\n');
        const formattedLines = lines.map(line => line ? before + line : line);
        const newText = beforeText + formattedLines.join('\n') + after + afterText;
        setContents(newText);
        
        // Set cursor position after insertion
        setTimeout(() => {
          const newPosition = start + (formattedLines.join('\n').length) + after.length;
          textarea.setSelectionRange(newPosition, newPosition);
          textarea.focus();
        }, 0);
      } else {
        // Insert at cursor with proper line breaks
        const needsLineBreak = start > 0 && beforeText[start - 1] !== '\n';
        const prefix = needsLineBreak ? '\n' : '';
        const newText = beforeText + prefix + before + after + '\n' + afterText;
        setContents(newText);
        
        // Position cursor after the formatting prefix
        setTimeout(() => {
          const newPosition = start + prefix.length + before.length;
          textarea.setSelectionRange(newPosition, newPosition);
          textarea.focus();
        }, 0);
      }
    } else {
      // Handle inline formatting (bold, italic, links)
      const placeholder = selectedText || (before === '[' ? 'link text' : 'text');
      const newText = beforeText + before + placeholder + after + afterText;
      setContents(newText);
      
      // Set cursor position to select placeholder
      setTimeout(() => {
        const selectStart = start + before.length;
        const selectEnd = selectStart + placeholder.length;
        textarea.setSelectionRange(selectStart, selectEnd);
        textarea.focus();
      }, 0);
    }
  };

  return (
    <div className="min-h-screen">
      {/* Editor Header */}
      <div className="sticky top-16 z-40 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-14">
            <Button variant="ghost" size="sm" className="gap-2" onClick={handleCancel}>
              <ArrowLeft className="w-4 h-4" />
              Cancel
            </Button>
            
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 text-sm">
                <Switch
                  id="visibility"
                  checked={isPublic}
                  onCheckedChange={setIsPublic}
                />
                <Label htmlFor="visibility" className="cursor-pointer">
                  {isPublic ? 'Public' : 'Private'}
                </Label>
              </div>
              <Button onClick={handleSave} disabled={!title || !contents || isSaving} className="gap-2">
                <Save className="w-4 h-4" />
                {isSaving ? 'Saving...' : 'Publish'}
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Metadata Panel */}
          <div className="mb-8">
            <div className="bg-card border border-border rounded-lg p-6">
              <div className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="title" className="text-base">Title</Label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Give your entry a title..."
                    className="text-xl bg-input-background border-border/50 focus:border-border"
                  />
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="sourceType">Source Type</Label>
                    <Select value={sourceType} onValueChange={(value: 'article' | 'book') => setSourceType(value)}>
                      <SelectTrigger id="sourceType" className="bg-input-background">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="article">Article</SelectItem>
                        <SelectItem value="book">Book</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {sourceType === 'book' && (
                    <div className="space-y-2">
                      <Label htmlFor="bookTitle">Book Title</Label>
                      <Input
                        id="bookTitle"
                        value={bookTitle}
                        onChange={(e) => setBookTitle(e.target.value)}
                        placeholder="The book this is from..."
                        className="bg-input-background"
                      />
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tags">Tags</Label>
                  <Input
                    id="tags"
                    value={tags}
                    onChange={(e) => setTags(e.target.value)}
                    placeholder="philosophy, design, writing"
                    className="bg-input-background"
                  />
                  <p className="text-xs text-muted-foreground">
                    Separate tags with commas
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Writing Area */}
          <div>
            <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as 'write' | 'preview')}>
              <div className="flex items-center justify-between mb-4">
                <TabsList>
                  <TabsTrigger value="write" className="gap-2">
                    <Edit3 className="w-4 h-4" />
                    Write
                  </TabsTrigger>
                  <TabsTrigger value="preview" className="gap-2">
                    <Eye className="w-4 h-4" />
                    Preview
                  </TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="write" className="mt-0">
                <MarkdownToolbar onInsert={handleMarkdownInsert} />
                <Textarea
                  ref={textareaRef}
                  value={contents}
                  onChange={(e) => setContents(e.target.value)}
                  placeholder="Begin writing your thoughts..."
                  className="min-h-[600px] resize-none font-serif text-lg leading-relaxed bg-card border-border/50 focus:border-border"
                />
              </TabsContent>

              <TabsContent value="preview" className="mt-0">
                <div className="bg-card border border-border rounded-lg p-8 sm:p-12 min-h-[600px]">
                  {contents ? (
                    <div className="prose-custom">
                      <ReactMarkdown
                        remarkPlugins={[remarkGfm]}
                        components={{
                          h1: ({ children }) => <h2 className="text-3xl font-semibold mt-8 mb-4 first:mt-0">{children}</h2>,
                          h2: ({ children }) => <h3 className="text-2xl font-semibold mt-6 mb-3">{children}</h3>,
                          h3: ({ children }) => <h4 className="text-xl font-semibold mt-5 mb-3">{children}</h4>,
                          p: ({ children }) => <p className="mb-6 leading-relaxed text-lg">{children}</p>,
                          blockquote: ({ children }) => (
                            <blockquote className="border-l-4 border-border pl-6 my-6 italic text-foreground/80">
                              {children}
                            </blockquote>
                          ),
                          ul: ({ children }) => <ul className="list-disc list-inside mb-6 space-y-2 text-lg">{children}</ul>,
                          ol: ({ children }) => <ol className="list-decimal list-inside mb-6 space-y-2 text-lg">{children}</ol>,
                          a: ({ children, href }) => (
                            <a href={href} className="text-primary hover:underline" target="_blank" rel="noopener noreferrer">
                              {children}
                            </a>
                          ),
                          strong: ({ children }) => <strong className="font-semibold">{children}</strong>,
                          em: ({ children }) => <em className="italic">{children}</em>,
                        }}
                      >
                        {contents}
                      </ReactMarkdown>
                    </div>
                  ) : (
                    <p className="text-muted-foreground italic text-center py-20">
                      Nothing to preview yet. Start writing to see your content rendered.
                    </p>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}