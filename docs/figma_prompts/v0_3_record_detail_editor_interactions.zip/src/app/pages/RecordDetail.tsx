import { useParams, Link } from 'react-router';
import { getRecordById, getCommentsByRecordId, getRelatedRecords, getCurrentUser } from '../data/mockData';
import { TagBadge } from '../components/TagBadge';
import { CommentSection } from '../components/CommentSection';
import { format } from 'date-fns';
import { BookOpen, FileText, ArrowLeft } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Button } from '../components/ui/button';

export function RecordDetail() {
  const { id } = useParams<{ id: string }>();
  const record = id ? getRecordById(id) : undefined;
  const comments = id ? getCommentsByRecordId(id) : [];
  const relatedRecords = id ? getRelatedRecords(id) : [];
  const currentUser = getCurrentUser();

  if (!record) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <h2 className="text-3xl mb-4">Record not found</h2>
        <Button asChild variant="outline">
          <Link to="/">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Library
          </Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Back Navigation */}
      <div className="mb-8">
        <Button asChild variant="ghost" size="sm" className="gap-2 -ml-2">
          <Link to="/">
            <ArrowLeft className="w-4 h-4" />
            Library
          </Link>
        </Button>
      </div>

      {/* Article Header */}
      <article>
        <header className="mb-12">
          <div className="flex items-center gap-2 mb-4 text-muted-foreground">
            {record.sourceType === 'book' ? (
              <BookOpen className="w-5 h-5" />
            ) : (
              <FileText className="w-5 h-5" />
            )}
            {record.sourceType === 'book' && record.bookTitle && (
              <span className="text-sm italic">from {record.bookTitle}</span>
            )}
          </div>

          <h1 className="text-4xl sm:text-5xl mb-6 leading-tight">
            {record.title}
          </h1>

          <div className="flex flex-wrap items-center gap-3 text-base text-muted-foreground mb-6">
            <span className="font-medium text-foreground">{record.writer}</span>
            <span>·</span>
            <time dateTime={record.publishedDate}>
              {format(new Date(record.publishedDate), 'MMMM d, yyyy')}
            </time>
          </div>

          <div className="flex flex-wrap gap-2">
            {record.tags.map(tag => (
              <TagBadge key={tag} tag={tag} />
            ))}
          </div>
        </header>

        {/* Article Content */}
        <div className="prose-custom mb-16">
          <ReactMarkdown
            remarkPlugins={[remarkGfm]}
            components={{
              h1: ({ children }) => <h2 className="text-3xl font-semibold mt-12 mb-4">{children}</h2>,
              h2: ({ children }) => <h3 className="text-2xl font-semibold mt-10 mb-3">{children}</h3>,
              h3: ({ children }) => <h4 className="text-xl font-semibold mt-8 mb-3">{children}</h4>,
              p: ({ children }) => <p className="mb-6 leading-relaxed text-lg">{children}</p>,
              blockquote: ({ children }) => (
                <blockquote className="border-l-4 border-border pl-6 my-8 italic text-foreground/80">
                  {children}
                </blockquote>
              ),
              ul: ({ children }) => <ul className="list-disc list-inside mb-6 space-y-2 text-lg">{children}</ul>,
              ol: ({ children }) => <ol className="list-decimal list-inside mb-6 space-y-2 text-lg">{children}</ol>,
              li: ({ children }) => <li className="leading-relaxed">{children}</li>,
              strong: ({ children }) => <strong className="font-semibold">{children}</strong>,
              em: ({ children }) => <em className="italic">{children}</em>,
            }}
          >
            {record.contents}
          </ReactMarkdown>
        </div>

        {/* Related Records */}
        {relatedRecords.length > 0 && (
          <aside className="mb-16 pt-12 border-t border-border">
            <h3 className="text-2xl mb-6">Related Reading</h3>
            <div className="grid gap-4">
              {relatedRecords.map(related => (
                <Link
                  key={related.id}
                  to={`/record/${related.id}`}
                  className="block p-5 bg-muted/30 hover:bg-muted/50 border border-border rounded-lg transition-colors group"
                >
                  <div className="flex items-start gap-3">
                    <div className="text-muted-foreground mt-1">
                      {related.sourceType === 'book' ? (
                        <BookOpen className="w-4 h-4" />
                      ) : (
                        <FileText className="w-4 h-4" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-lg mb-1 group-hover:text-primary/80 transition-colors">
                        {related.title}
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        {related.writer} · {format(new Date(related.publishedDate), 'MMM d, yyyy')}
                      </p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </aside>
        )}

        {/* Comments */}
        <CommentSection comments={comments} isAuthenticated={!!currentUser} />
      </article>
    </div>
  );
}