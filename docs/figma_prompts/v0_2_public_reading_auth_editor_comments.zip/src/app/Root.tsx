import { Outlet } from 'react-router';
import { Header } from './components/Header';

export function Root() {
  // In a real app, this would check actual auth state
  const isAuthenticated = false;

  return (
    <div className="min-h-screen flex flex-col">
      <Header isAuthenticated={isAuthenticated} />
      <main className="flex-1">
        <Outlet />
      </main>
      <footer className="border-t border-border bg-card/30 mt-auto">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-sm text-muted-foreground">
            <p>Personal Wiki · A space for thoughtful writing and reading</p>
            <p className="mt-2">© 2026 All rights reserved</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
