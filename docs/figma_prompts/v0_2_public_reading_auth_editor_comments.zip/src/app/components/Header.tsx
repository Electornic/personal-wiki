import { Link } from 'react-router';
import { PenLine, User } from 'lucide-react';
import { Button } from './ui/button';

interface HeaderProps {
  isAuthenticated?: boolean;
}

export function Header({ isAuthenticated = false }: HeaderProps) {
  return (
    <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center space-x-2 hover:opacity-70 transition-opacity">
            <h1 className="text-xl tracking-tight">Personal Wiki</h1>
          </Link>
          
          <nav className="flex items-center gap-3">
            {isAuthenticated ? (
              <>
                <Button asChild variant="ghost" size="sm" className="gap-2">
                  <Link to="/editor">
                    <PenLine className="w-4 h-4" />
                    <span className="hidden sm:inline">Write</span>
                  </Link>
                </Button>
                <Button asChild variant="ghost" size="sm" className="gap-2">
                  <Link to="/profile">
                    <User className="w-4 h-4" />
                    <span className="hidden sm:inline">Profile</span>
                  </Link>
                </Button>
              </>
            ) : (
              <Button asChild variant="default" size="sm">
                <Link to="/auth">Sign In</Link>
              </Button>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
}
