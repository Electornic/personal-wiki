import { createBrowserRouter } from 'react-router';
import { Root } from './Root';
import { Home } from './pages/Home';
import { RecordDetail } from './pages/RecordDetail';
import { Auth } from './pages/Auth';
import { Editor } from './pages/Editor';
import { NotFound } from './pages/NotFound';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: 'record/:id', Component: RecordDetail },
      { path: 'auth', Component: Auth },
      { path: 'editor', Component: Editor },
      { path: 'editor/:id', Component: Editor },
      { path: '*', Component: NotFound },
    ],
  },
]);
