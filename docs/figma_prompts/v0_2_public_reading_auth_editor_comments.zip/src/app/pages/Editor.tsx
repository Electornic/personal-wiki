import { useState } from 'react';
import { useNavigate, Link } from 'react-router';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Switch } from '../components/ui/switch';
import { ArrowLeft, Eye, Save } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';

export function Editor() {
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [contents, setContents] = useState('');
  const [sourceType, setSourceType] = useState<'article' | 'book'>('article');
  const [bookTitle, setBookTitle] = useState('');
  const [isPublic, setIsPublic] = useState(true);
  const [tags, setTags] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [activeTab, setActiveTab] = useState<'write' | 'preview'>('write');

  const handleSave = async () => {
    setIsSaving(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSaving(false);
      navigate('/');
    }, 1000);
  };

  return (
    <div className="min-h-screen">
      {/* Editor Header */}
      <div className="sticky top-16 z-40 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-14">
            <Button asChild variant="ghost" size="sm" className="gap-2">
              <Link to="/">
                <ArrowLeft className="w-4 h-4" />
                Cancel
              </Link>
            </Button>
            
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 text-sm">
                <Switch
                  id="visibility"
                  checked={isPublic}
                  onCheckedChange={setIsPublic}
                />
                <Label htmlFor="visibility" className="cursor-pointer">
                  {isPublic ? 'Public' : 'Private'}
                </Label>
              </div>
              <Button onClick={handleSave} disabled={!title || !contents || isSaving} className="gap-2">
                <Save className="w-4 h-4" />
                {isSaving ? 'Saving...' : 'Publish'}
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Metadata Panel */}
          <div className="lg:col-span-2">
            <div className="bg-card border border-border rounded-lg p-6 mb-8">
              <h2 className="text-xl mb-6">Entry Details</h2>
              
              <div className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Give your entry a title..."
                    className="text-xl bg-input-background"
                  />
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="sourceType">Source Type</Label>
                    <Select value={sourceType} onValueChange={(value: 'article' | 'book') => setSourceType(value)}>
                      <SelectTrigger id="sourceType" className="bg-input-background">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="article">Article</SelectItem>
                        <SelectItem value="book">Book</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {sourceType === 'book' && (
                    <div className="space-y-2">
                      <Label htmlFor="bookTitle">Book Title</Label>
                      <Input
                        id="bookTitle"
                        value={bookTitle}
                        onChange={(e) => setBookTitle(e.target.value)}
                        placeholder="The book this is from..."
                        className="bg-input-background"
                      />
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tags">Tags</Label>
                  <Input
                    id="tags"
                    value={tags}
                    onChange={(e) => setTags(e.target.value)}
                    placeholder="philosophy, design, writing (comma-separated)"
                    className="bg-input-background"
                  />
                  <p className="text-xs text-muted-foreground">
                    Separate tags with commas to help readers discover related entries
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Writing Area */}
          <div className="lg:col-span-2">
            <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as 'write' | 'preview')}>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl">Content</h2>
                <TabsList>
                  <TabsTrigger value="write">Write</TabsTrigger>
                  <TabsTrigger value="preview" className="gap-2">
                    <Eye className="w-4 h-4" />
                    Preview
                  </TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="write" className="mt-0">
                <Textarea
                  value={contents}
                  onChange={(e) => setContents(e.target.value)}
                  placeholder="Begin writing... Markdown is supported."
                  className="min-h-[600px] resize-none font-serif text-lg leading-relaxed bg-input-background"
                />
                <div className="mt-3 text-sm text-muted-foreground">
                  <p>Markdown supported: **bold**, *italic*, # headings, {`>`} blockquotes, - lists</p>
                </div>
              </TabsContent>

              <TabsContent value="preview" className="mt-0">
                <div className="bg-card border border-border rounded-lg p-8 min-h-[600px]">
                  {contents ? (
                    <div className="prose-custom">
                      <ReactMarkdown
                        remarkPlugins={[remarkGfm]}
                        components={{
                          h1: ({ children }) => <h2 className="text-3xl font-semibold mt-8 mb-4 first:mt-0">{children}</h2>,
                          h2: ({ children }) => <h3 className="text-2xl font-semibold mt-6 mb-3">{children}</h3>,
                          h3: ({ children }) => <h4 className="text-xl font-semibold mt-5 mb-3">{children}</h4>,
                          p: ({ children }) => <p className="mb-6 leading-relaxed text-lg">{children}</p>,
                          blockquote: ({ children }) => (
                            <blockquote className="border-l-4 border-border pl-6 my-6 italic text-foreground/80">
                              {children}
                            </blockquote>
                          ),
                          ul: ({ children }) => <ul className="list-disc list-inside mb-6 space-y-2 text-lg">{children}</ul>,
                          ol: ({ children }) => <ol className="list-decimal list-inside mb-6 space-y-2 text-lg">{children}</ol>,
                        }}
                      >
                        {contents}
                      </ReactMarkdown>
                    </div>
                  ) : (
                    <p className="text-muted-foreground italic">Nothing to preview yet. Start writing to see your content rendered.</p>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}