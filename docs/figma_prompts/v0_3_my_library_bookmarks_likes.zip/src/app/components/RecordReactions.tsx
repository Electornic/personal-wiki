import { useState, useEffect } from 'react';
import { Bookmark, Heart } from 'lucide-react';
import { Button } from './ui/button';
import { toggleBookmark, toggleLike, isBookmarked, isLiked } from '../data/mockData';
import { cn } from './ui/utils';

interface RecordReactionsProps {
  recordId: string;
  isAuthenticated: boolean;
}

export function RecordReactions({ recordId, isAuthenticated }: RecordReactionsProps) {
  const [bookmarked, setBookmarked] = useState(false);
  const [liked, setLiked] = useState(false);

  useEffect(() => {
    if (isAuthenticated) {
      setBookmarked(isBookmarked(recordId));
      setLiked(isLiked(recordId));
    }
  }, [recordId, isAuthenticated]);

  useEffect(() => {
    const handleReactionsChange = () => {
      if (isAuthenticated) {
        setBookmarked(isBookmarked(recordId));
        setLiked(isLiked(recordId));
      }
    };

    window.addEventListener('reactionsChange', handleReactionsChange);
    return () => window.removeEventListener('reactionsChange', handleReactionsChange);
  }, [recordId, isAuthenticated]);

  if (!isAuthenticated) {
    return null;
  }

  const handleBookmark = () => {
    toggleBookmark(recordId);
    setBookmarked(!bookmarked);
  };

  const handleLike = () => {
    toggleLike(recordId);
    setLiked(!liked);
  };

  return (
    <div className="flex items-center gap-3 py-6 border-y border-border">
      <Button
        variant="ghost"
        size="sm"
        onClick={handleBookmark}
        className={cn(
          'gap-2 transition-colors',
          bookmarked
            ? 'text-foreground hover:text-foreground/80'
            : 'text-muted-foreground hover:text-foreground'
        )}
        aria-label={bookmarked ? 'Remove bookmark' : 'Bookmark this record'}
      >
        <Bookmark
          className={cn('w-4 h-4', bookmarked && 'fill-current')}
        />
        <span className="text-sm">
          {bookmarked ? 'Bookmarked' : 'Bookmark'}
        </span>
      </Button>

      <div className="h-4 w-px bg-border" />

      <Button
        variant="ghost"
        size="sm"
        onClick={handleLike}
        className={cn(
          'gap-2 transition-colors',
          liked
            ? 'text-foreground hover:text-foreground/80'
            : 'text-muted-foreground hover:text-foreground'
        )}
        aria-label={liked ? 'Unlike this record' : 'Like this record'}
      >
        <Heart
          className={cn('w-4 h-4', liked && 'fill-current')}
        />
        <span className="text-sm">
          {liked ? 'Liked' : 'Like'}
        </span>
      </Button>
    </div>
  );
}
