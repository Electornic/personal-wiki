import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router';
import { getCurrentUser, getBookmarkedRecords, getLikedRecords } from '../data/mockData';
import { RecordCard } from '../components/RecordCard';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui/tabs';
import { Bookmark, Heart } from 'lucide-react';

export function Library() {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(getCurrentUser());
  const [bookmarkedRecords, setBookmarkedRecords] = useState(getBookmarkedRecords());
  const [likedRecords, setLikedRecords] = useState(getLikedRecords());

  useEffect(() => {
    const user = getCurrentUser();
    if (!user) {
      navigate('/auth');
      return;
    }
    setCurrentUser(user);
    loadRecords();
  }, [navigate]);

  useEffect(() => {
    const handleAuthChange = () => {
      const user = getCurrentUser();
      if (!user) {
        navigate('/auth');
      } else {
        setCurrentUser(user);
        loadRecords();
      }
    };

    const handleReactionsChange = () => {
      loadRecords();
    };

    window.addEventListener('authChange', handleAuthChange);
    window.addEventListener('reactionsChange', handleReactionsChange);
    
    return () => {
      window.removeEventListener('authChange', handleAuthChange);
      window.removeEventListener('reactionsChange', handleReactionsChange);
    };
  }, [navigate]);

  const loadRecords = () => {
    setBookmarkedRecords(getBookmarkedRecords());
    setLikedRecords(getLikedRecords());
  };

  if (!currentUser) {
    return null;
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Header */}
      <header className="mb-12">
        <h1 className="text-4xl mb-3">My Library</h1>
        <p className="text-lg text-muted-foreground">
          Your personal collection of saved reading
        </p>
      </header>

      {/* Tabs */}
      <Tabs defaultValue="bookmarks" className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-2 mb-8">
          <TabsTrigger value="bookmarks" className="gap-2">
            <Bookmark className="w-4 h-4" />
            Bookmarks
          </TabsTrigger>
          <TabsTrigger value="likes" className="gap-2">
            <Heart className="w-4 h-4" />
            Likes
          </TabsTrigger>
        </TabsList>

        {/* Bookmarks Tab */}
        <TabsContent value="bookmarks" className="mt-0">
          {bookmarkedRecords.length > 0 ? (
            <div className="grid gap-6 sm:grid-cols-2">
              {bookmarkedRecords.map((record) => (
                <RecordCard key={record.id} record={record} />
              ))}
            </div>
          ) : (
            <div className="py-20 text-center">
              <Bookmark className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
              <h3 className="text-xl mb-2">No bookmarks yet</h3>
              <p className="text-muted-foreground mb-6">
                Bookmark records you want to return to later
              </p>
              <Link
                to="/"
                className="text-sm text-foreground hover:underline underline-offset-4"
              >
                Browse the library
              </Link>
            </div>
          )}
        </TabsContent>

        {/* Likes Tab */}
        <TabsContent value="likes" className="mt-0">
          {likedRecords.length > 0 ? (
            <div className="grid gap-6 sm:grid-cols-2">
              {likedRecords.map((record) => (
                <RecordCard key={record.id} record={record} />
              ))}
            </div>
          ) : (
            <div className="py-20 text-center">
              <Heart className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
              <h3 className="text-xl mb-2">No likes yet</h3>
              <p className="text-muted-foreground mb-6">
                Like records that resonate with you
              </p>
              <Link
                to="/"
                className="text-sm text-foreground hover:underline underline-offset-4"
              >
                Browse the library
              </Link>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
